"""Edição de vídeo com IA — processamento local com FFmpeg e Whisper."""
__version__ = "0.5.0"
